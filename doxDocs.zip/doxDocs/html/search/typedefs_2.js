var searchData=
[
  ['funkcja_5fbledu_763',['funkcja_bledu',['../classwbrtm_1_1TabelaTabDelimited.html#aa1270b0208b54c164fc40e567ae9cc94',1,'wbrtm::TabelaTabDelimited']]]
];
