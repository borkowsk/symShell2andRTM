var searchData=
[
  ['platform_2eh_469',['platform.h',['../platform_8h.html',1,'']]],
  ['platform_2ehpp_470',['platform.hpp',['../platform_8hpp.html',1,'']]]
];
