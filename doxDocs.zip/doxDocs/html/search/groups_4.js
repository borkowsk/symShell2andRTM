var searchData=
[
  ['wirtualne_20konstruktory_20dla_20obiektów_20heterogenicznych_810',['Wirtualne konstruktory dla obiektów heterogenicznych',['../group__VirtualConstruction.html',1,'']]]
];
