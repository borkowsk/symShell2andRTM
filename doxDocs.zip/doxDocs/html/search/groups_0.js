var searchData=
[
  ['błędne_20i_20wyjątkowe_20sytuacje_806',['Błędne i wyjątkowe sytuacje',['../group__ERRORHANDLING.html',1,'']]]
];
