var searchData=
[
  ['jakanazwa_581',['JakaNazwa',['../classwbrtm_1_1TabelaTabDelimited.html#a6ab3895b0d73381e1f850de5a5d0797a',1,'wbrtm::TabelaTabDelimited']]],
  ['jakidelimiter_582',['JakiDelimiter',['../classwbrtm_1_1TabelaTabDelimited.html#a36d505b1ad654d8f6b9332e1d7d9d432',1,'wbrtm::TabelaTabDelimited']]]
];
