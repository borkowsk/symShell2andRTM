var searchData=
[
  ['alloc_5ferror_5fobsolete_768',['ALLOC_ERROR_OBSOLETE',['../classwbrtm_1_1error__handling.html#ae79e387e604e184e26598fe7003c76c5ad52347490f60945af8735926b93c9235',1,'wbrtm::error_handling']]]
];
