var searchData=
[
  ['pointer_766',['pointer',['../namespacewbrtm.html#a0b2f42549c6ea606cf937bdd73559149',1,'wbrtm']]]
];
