var searchData=
[
  ['default_5fmissing_404',['default_missing',['../classdefault__missing.html',1,'default_missing&lt; Scalar &gt;'],['../classwbrtm_1_1default__missing.html',1,'wbrtm::default_missing&lt; Scalar &gt;']]]
];
