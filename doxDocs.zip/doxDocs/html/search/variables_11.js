var searchData=
[
  ['reverse_744',['reverse',['../classwbrtm_1_1assoc__base.html#ae1f1ace577e4ac7e82e8d7d9a69063a1',1,'wbrtm::assoc_base']]],
  ['rozmiar_745',['Rozmiar',['../classwbrtm_1_1TabelaTabDelimited.html#a885f4ef4add1ac8e45160819590a239c',1,'wbrtm::TabelaTabDelimited']]]
];
