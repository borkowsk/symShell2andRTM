var searchData=
[
  ['range_5ferror_776',['RANGE_ERROR',['../classwbrtm_1_1error__handling.html#ae79e387e604e184e26598fe7003c76c5a7f95c4d5aa0802aab3d60428c020d1e4',1,'wbrtm::error_handling']]]
];
