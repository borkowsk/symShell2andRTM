var indexSectionsWithContent =
{
  0: "_abcdefghijklmnoprstuvwz~",
  1: "_abcdeilmnoprstvw",
  2: "w",
  3: "_abceiloprstvw",
  4: "_abcdefghijklmnoprstuvwz~",
  5: "_abcdefghijklmnoprstvw",
  6: "cefiop",
  7: "e",
  8: "ainor",
  9: "iors",
  10: "_adefhorsuw",
  11: "biorwz",
  12: "s"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "enums",
  8: "enumvalues",
  9: "related",
  10: "defines",
  11: "groups",
  12: "pages"
};

var indexSectionLabels =
{
  0: "Wszystko",
  1: "Struktury Danych",
  2: "Przestrzenie nazw",
  3: "Pliki",
  4: "Funkcje",
  5: "Zmienne",
  6: "Definicje typów",
  7: "Wyliczenia",
  8: "Wartości wyliczeń",
  9: "Przyjaciele",
  10: "Definicje",
  11: "Grupay",
  12: "Strony"
};

