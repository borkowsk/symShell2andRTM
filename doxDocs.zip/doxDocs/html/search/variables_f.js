var searchData=
[
  ['opisowo_741',['Opisowo',['../classwbrtm_1_1TabelaTabDelimited.html#af797af89052f52d1db6472a929bcb29a',1,'wbrtm::TabelaTabDelimited']]]
];
