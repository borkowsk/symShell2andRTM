var searchData=
[
  ['aktualnafunkcjabledu_709',['AktualnaFunkcjaBledu',['../classwbrtm_1_1TabelaTabDelimited.html#aab299afdc33b6407a673d10ac8a091f7',1,'wbrtm::TabelaTabDelimited']]]
];
