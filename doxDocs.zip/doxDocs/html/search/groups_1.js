var searchData=
[
  ['informacja_20o_20typach_20i_20nazewnictwo_807',['Informacja o typach i nazewnictwo',['../group__TypesService.html',1,'']]]
];
