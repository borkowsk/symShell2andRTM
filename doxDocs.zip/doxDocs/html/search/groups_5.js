var searchData=
[
  ['zarządzanie_20danymi_20na_20stercie_811',['Zarządzanie danymi na stercie',['../group__DYNMEMORY.html',1,'']]],
  ['zbyt_20stare_20fragmenty_20biblioteki_20jeszcze_20nie_20w_20pełni_20przystosowane_20do_20c_2b_2b11_812',['Zbyt stare fragmenty biblioteki jeszcze nie w pełni przystosowane do C++11',['../group__OBSOLETE.html',1,'']]]
];
