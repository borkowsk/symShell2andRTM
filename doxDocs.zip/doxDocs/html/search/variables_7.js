var searchData=
[
  ['g_5fmem_5fmode_721',['g_mem_mode',['../classwbrtm_1_1array__of__ptr.html#a5d37ba4dd7dd9ef13f5587f6b299437c',1,'wbrtm::array_of_ptr']]]
];
