var searchData=
[
  ['jakanazwa_163',['JakaNazwa',['../classwbrtm_1_1TabelaTabDelimited.html#a6ab3895b0d73381e1f850de5a5d0797a',1,'wbrtm::TabelaTabDelimited']]],
  ['jakidelimiter_164',['JakiDelimiter',['../classwbrtm_1_1TabelaTabDelimited.html#a36d505b1ad654d8f6b9332e1d7d9d432',1,'wbrtm::TabelaTabDelimited']]],
  ['juz_5fbylo_165',['juz_bylo',['../namespacewbrtm.html#a43274559fb75b4d1cf93548158c40af5',1,'wbrtm']]]
];
